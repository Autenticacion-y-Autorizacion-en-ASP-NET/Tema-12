namespace CleanArchitecture.Application.Users.GetUsersDapperPagination;


public class UserPaginationData
{

    public string? Email {get;set;}
    public string? Role {get;set;}
    public string? Permiso {get;set;}

}