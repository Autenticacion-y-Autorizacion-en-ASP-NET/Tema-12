namespace CleanArchitecture.Api.Utils;

public static class ApiVersions
{

    public const string V1 = "1";
    public const string V2 = "2";

}